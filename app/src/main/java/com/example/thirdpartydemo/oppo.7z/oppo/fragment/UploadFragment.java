package com.example.thirdpartydemo.oppo.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.thirdpartydemo.R;
import com.example.thirdpartydemo.oppo.customview.DownloadProgressView;

public class UploadFragment extends Fragment {

    private DownloadProgressView vDownloadProgressView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_upload, container, false);
        vDownloadProgressView = view.findViewById(R.id.download_progress);
        //设置进度监听
        vDownloadProgressView.setOnProgressUpdateListener(new DownloadProgressView.OnProgressUpdateListener() {
            @Override
            public void onProgressUpdate(int progress) {
                //vProgressIndicator.setText("当前进度：" + progress);
            }
        });
        //手动设置当前进度
        vDownloadProgressView.setProgress(0);
        //设置最大值
        vDownloadProgressView.setMaxProgress(100);
        return view;
    }
}
